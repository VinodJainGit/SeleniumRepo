package oops.inheritence;

public class Telephone 
{

	public void calling()
	{
		
		System.out.println("Calling from Telephone");
	}

}
