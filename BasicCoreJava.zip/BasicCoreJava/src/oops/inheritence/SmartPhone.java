package oops.inheritence;

public class SmartPhone extends Mobile
{

	public void internet()
	{
		
		System.out.println("Net surfing from smartphone");
	}

}
