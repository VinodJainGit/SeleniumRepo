package conditionalStatements;

public class LogicalOperators2 {

	public static void main(String[] args) {
		int Salary=50000;
		int Mortgage=2000000;
		
		if (Salary>=50000 || Mortgage>=2000000) {
			System.out.println("You are eligible");
			
		}
		else
		{
			System.out.println("You are not eligible");
		}
		

	}

}
