package opps.abstraction;

public abstract class ExcelApplication
{
	public abstract void spreadsheet();
	public abstract void save();
	public abstract void delete();
	public abstract void update();
	public abstract void formating();
	public abstract void filter();

	
}
