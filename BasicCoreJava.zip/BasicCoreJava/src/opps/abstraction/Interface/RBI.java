package opps.abstraction.Interface;

public interface RBI 
{
	public void savingAccount();
	public void currentAccount();
	public void debitCard();
	public void creditCard();
	
	

}
