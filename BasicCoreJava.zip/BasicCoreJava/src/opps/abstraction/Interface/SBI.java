package opps.abstraction.Interface;

public class SBI implements RBI
{

	@Override
	public void savingAccount() {
		// TODO Auto-generated method stub
		System.out.println("Saving Account in SBI");
	}

	@Override
	public void currentAccount() {
		// TODO Auto-generated method stub
		System.out.println("Current Account in SBI");
	}

	@Override
	public void debitCard() {
		// TODO Auto-generated method stub
		System.out.println("Debit card in SBI");
	}

	@Override
	public void creditCard() {
		// TODO Auto-generated method stub
		System.out.println("Credit card in SBI");
	}

	
}
