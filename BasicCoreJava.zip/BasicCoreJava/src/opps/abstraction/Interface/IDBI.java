package opps.abstraction.Interface;

public class IDBI implements RBI
{
	@Override
	public void savingAccount() {
		// TODO Auto-generated method stub
		System.out.println("Saving Account in IDBI");
	}

	@Override
	public void currentAccount() {
		// TODO Auto-generated method stub
		System.out.println("Current Account in IDBI");
	}

	@Override
	public void debitCard() {
		// TODO Auto-generated method stub
		System.out.println("Debit card in IDBI");
	}

	@Override
	public void creditCard() {
		// TODO Auto-generated method stub
		System.out.println("Credit card in IDBI");
	}

}
