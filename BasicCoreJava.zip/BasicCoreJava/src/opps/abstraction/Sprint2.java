package opps.abstraction;

public abstract class Sprint2 extends Sprint1
{
	public void delete()
	{
		System.out.println("Delete");
	}
	public void update()
	{
		System.out.println("Update");
	}

}
