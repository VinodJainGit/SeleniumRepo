package opps.abstraction;

public class Sprint3 extends Sprint2
{

	public void formating()
	{
		System.out.println("Formating");
	}
	public void filter()
	{
		System.out.println("Filter");
	}
}
