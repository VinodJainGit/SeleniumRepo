package opps.abstraction;

public abstract class Sprint1 extends ExcelApplication
{
	public void spreadsheet()
	{
		System.out.println("Spreadsheets");
	}
	public void save()
	{
		System.out.println("Save");
	}

}
