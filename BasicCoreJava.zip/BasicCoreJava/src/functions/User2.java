package functions;

public class User2 {

	public static void main(String[] args)
	{
		Car BMW = new Car("Gray","X1");
		BMW.specification();
		
		Car maruti=new Car();
		maruti.color="white";
		maruti.model="swift";
		maruti.specification();
		

	}

}
