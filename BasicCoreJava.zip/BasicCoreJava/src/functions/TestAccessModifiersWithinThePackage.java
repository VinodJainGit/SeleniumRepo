package functions;

public class TestAccessModifiersWithinThePackage {

	public static void main(String[] args) 
	{
		AccessModifiers obj=new AccessModifiers();
		obj.publicFunction();
		
		obj.defaultFunction();
		
		obj.protectedFunction();

	}

}
