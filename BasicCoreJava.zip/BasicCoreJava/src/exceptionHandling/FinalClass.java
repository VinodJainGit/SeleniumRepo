package exceptionHandling;

public  class FinalClass {

	
public  void test() 
{
	
}

}
