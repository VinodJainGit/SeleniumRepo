package exceptionHandling;

public class FinalVariable extends FinalClass
{

	public final static int age=30;
	
	public static void main(String[] args) 
	{
		
		//age=31;
		

	}
	
	public void test()
	{
		
	}

}
