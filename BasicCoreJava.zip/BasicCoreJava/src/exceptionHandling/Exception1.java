package exceptionHandling;

public class Exception1 {

	public static void main(String[] args) 
	{
		int a=10;
		int b=0;
		
		//System.out.println(a/b);
		
		String str="Anand";
		System.out.println(str.charAt(7));

	}
	
	public static void sleep(int a) 
	{
		System.out.println(a);
	}

}
