package exceptionHandling;

public class Exception2 {

	public static void main(String[] args) throws InterruptedException 
	{
		System.out.println("Vinod");
		
		Thread.sleep(5000);
		
		//Exception1.sleep(5000);
		
		System.out.println("Jain");

	}

}
