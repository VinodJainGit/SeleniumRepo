package collections;

public class ObjectArray 
{

	public static void main(String[] args) 
	{
		//We can store data with different data types in single array.
		Object [] obj=new Object[3];
		obj[0]=10;
		obj[1]=true;
		obj[2]="Vinod";

	}

}
