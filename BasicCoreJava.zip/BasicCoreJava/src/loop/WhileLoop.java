package loop;

public class WhileLoop {

	public static void main(String[] args)
	{
		//1. Initilization
		int i=0;
		
		//2. Condition
		while(i<10)
		{
			System.out.println(i);
		
			//3.Increment
			i++;
		}
		

	}

}
