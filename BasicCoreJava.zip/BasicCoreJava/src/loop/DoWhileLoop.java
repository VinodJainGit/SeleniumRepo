package loop;

public class DoWhileLoop {

	public static void main(String[] args)
	{
		int i=10;
		
		do
		{
			System.out.println(i);
		}while(i<10);
		
		
		while(i<10)
		{
			System.out.println(i);
		}

	}

}
