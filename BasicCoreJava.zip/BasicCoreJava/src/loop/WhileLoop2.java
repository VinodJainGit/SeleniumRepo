package loop;

public class WhileLoop2 {

	public static void main(String[] args)
	{
		int score=0;
		
		while(score<=50000)
		{
			score=score+1;
		}
		
		System.out.println(score);
		System.out.println("Completed");

	}

}
