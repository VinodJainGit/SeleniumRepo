package variablesAndDatatypes;

public class DataTypes {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//integer
		int age=30;
		System.out.println(age);
		
		//Character
		char gender='M';
	   System.out.println(gender);
	   
	   //Decimal values
	   double markes=7.4;
	   System.out.println(markes);
	   
	   
	   //Boolean values
	   boolean status=true;
	   System.out.println(status);
	   
	   //Strings
	   String name="Vinod";
	   System.out.println(name);
	   
	   //for integer values
	   byte a=10;
		/*
		 * short; int; long;
		 * 
		 * 
		 * //for decimal float; double;
		 */

	}

}
